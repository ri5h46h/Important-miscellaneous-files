==================================
pyttsx - Text-to-speech x-platform
==================================

This documentation describes the pyttsx Python package v |release| and was rendered on |today|.

.. rubric:: Table of Contents

.. toctree::
   :maxdepth: 2

   install
   engine
   drivers
   changelog

.. rubric:: Project Links

* `Project home page at GitHub`__
* `Package listing in PyPI`__
* `Documentation at ReadTheDocs`__

__ https://github.com/parente/pyttsx
__ http://pypi.python.org/pypi/pyttsx
__ https://pyttsx.readthedocs.org/